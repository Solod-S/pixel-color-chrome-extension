const u = {
  START_PICKER: "START_PICKER",
  REQUEST_SCREENSHOT: "REQUEST_SCREENSHOT",
  COLOR_PICKED: "COLOR_PICKED",
  OPEN_PAGE: "OPEN_PAGE"
}, d = {
  showMagnifier: !0,
  outlineHoveredElement: !0,
  useCrosshair: !0,
  autoCopy: !0,
  copyFormat: "hex-upper",
  saveHistory: !0,
  historyLimit: 50,
  sampleSize: 1,
  sampleMode: "average",
  afterPick: "exit"
}, i = {
  SETTINGS: "pixel_color_settings",
  HISTORY: "pixel_color_history",
  FAVORITES: "pixel_color_favorites"
};
async function h() {
  try {
    if (typeof chrome < "u" && chrome.storage && chrome.storage.local) {
      const t = await chrome.storage.local.get(i.SETTINGS);
      if (t && t[i.SETTINGS])
        return { ...d, ...t[i.SETTINGS] };
    } else if (typeof localStorage < "u") {
      const t = localStorage.getItem(i.SETTINGS);
      if (t)
        return { ...d, ...JSON.parse(t) };
    }
  } catch (t) {
    console.error("Error loading settings:", t);
  }
  return { ...d };
}
async function y() {
  try {
    if (typeof chrome < "u" && chrome.storage && chrome.storage.local) {
      const t = await chrome.storage.local.get(i.HISTORY);
      if (t && Array.isArray(t[i.HISTORY]))
        return t[i.HISTORY];
    } else if (typeof localStorage < "u") {
      const t = localStorage.getItem(i.HISTORY);
      if (t)
        return JSON.parse(t);
    }
  } catch (t) {
    console.error("Error reading history:", t);
  }
  return [];
}
async function T(t, e = {}) {
  if (!t) return null;
  const a = await h();
  if (!a.saveHistory) return null;
  const o = await y(), r = {
    id: `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    color: t,
    pickedAt: (/* @__PURE__ */ new Date()).toISOString(),
    sourceDomain: e.domain || "manual",
    sourceType: e.type || "page",
    // 'page' | 'system' | 'manual' | 'palette' | 'analyzer'
    favorite: !1
  }, c = [r, ...o], f = a.historyLimit || 50;
  let s = c;
  if (c.length > f) {
    const l = c.filter((n) => n.favorite), g = c.filter((n) => !n.favorite), S = Math.max(0, f - l.length);
    s = [
      ...l,
      ...g.slice(0, S)
    ], s.sort(
      (n, m) => new Date(m.pickedAt).getTime() - new Date(n.pickedAt).getTime()
    );
  }
  try {
    typeof chrome < "u" && chrome.storage && chrome.storage.local ? await chrome.storage.local.set({ [i.HISTORY]: s }) : typeof localStorage < "u" && localStorage.setItem(i.HISTORY, JSON.stringify(s));
  } catch (l) {
    console.error("Error saving color to history:", l);
  }
  return r;
}
function E(t) {
  return t ? t.startsWith("chrome://") || t.startsWith("chrome-extension://") || t.startsWith("view-source:") || t.startsWith("about:") || t.startsWith("edge://") || t.includes("chrome.google.com/webstore") || t.includes("chromewebstore.google.com") : !0;
}
async function p(t) {
  try {
    let e;
    if (t)
      try {
        e = await chrome.tabs.get(t);
      } catch (r) {
        console.warn("Could not get tab by targetTabId:", r);
      }
    if (!e) {
      const [r] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
      e = r;
    }
    if (!e || !e.id)
      return console.warn("No active tab found."), { success: !1, error: "No active tab" };
    if (E(e.url)) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: e.id },
          func: () => {
            alert("Pixel Color cannot inspect protected Chrome pages or Chrome Web Store.");
          }
        });
      } catch (r) {
        console.warn("Cannot show alert on protected page:", r);
      }
      return { success: !1, error: "Protected page" };
    }
    const a = await chrome.tabs.captureVisibleTab(e.windowId, { format: "png" }), o = await h();
    return await chrome.scripting.executeScript({
      target: { tabId: e.id },
      files: ["src/picker/picker.bundle.js"]
    }), await chrome.scripting.executeScript({
      target: { tabId: e.id },
      func: (r, c) => {
        typeof window.__initPixelColorPicker == "function" && window.__initPixelColorPicker(r, c);
      },
      args: [a, o]
    }), { success: !0 };
  } catch (e) {
    return console.error("Failed to start picker on tab:", e), { success: !1, error: e.message };
  }
}
chrome.commands.onCommand.addListener((t) => {
  t === "start-picker" && p();
});
chrome.runtime.onMessage.addListener((t, e, a) => {
  if (!(!t || !t.type))
    switch (t.type) {
      case u.START_PICKER: {
        const o = t.tabId || (e.tab ? e.tab.id : void 0);
        return p(o).then(a), !0;
      }
      case u.REQUEST_SCREENSHOT: {
        const o = e.tab ? e.tab.windowId : void 0;
        return chrome.tabs.captureVisibleTab(o, { format: "png" }).then((r) => {
          a({ dataUrl: r });
        }).catch((r) => {
          console.error("Recapture failed in background:", r), a({ dataUrl: null, error: r.message });
        }), !0;
      }
      case u.COLOR_PICKED: {
        if (t.payload && t.payload.color)
          return T(t.payload.color, {
            domain: t.payload.sourceDomain,
            type: t.payload.sourceType || "page"
          }).then((o) => {
            a({ success: !0, saved: o });
          }), !0;
        break;
      }
      case u.OPEN_PAGE: {
        if (t.payload && t.payload.page) {
          const o = chrome.runtime.getURL(t.payload.page);
          chrome.tabs.create({ url: o }), a({ success: !0 });
        }
        break;
      }
    }
});
